'use client';

import React, { useState } from 'react';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { formatDate } from '@/lib/utils';

const mockBackups = [
  { id: 1, name: 'z-ui-full-20260524_100000.tar.gz', type: 'full', size: '24.3 MB', admin: 'Admin', date: '2026-05-24T10:00:00Z' },
  { id: 2, name: 'z-ui-pre-update-20260523_080000.tar.gz', type: 'pre-update', size: '22.1 MB', admin: 'System', date: '2026-05-23T08:00:00Z' },
  { id: 3, name: 'z-ui-auto-20260522_000000.tar.gz', type: 'auto', size: '21.8 MB', admin: 'System', date: '2026-05-22T00:00:00Z' },
  { id: 4, name: 'z-ui-manual-20260520_143000.tar.gz', type: 'manual', size: '20.5 MB', admin: 'Admin', date: '2026-05-20T14:30:00Z' },
];

const typeBadge: Record<string, { bg: string; color: string }> = {
  full: { bg: 'rgba(0,180,255,.1)', color: 'var(--accent-1)' },
  auto: { bg: 'rgba(34,197,94,.1)', color: 'var(--success)' },
  manual: { bg: 'rgba(124,58,237,.1)', color: 'var(--accent-2)' },
  'pre-update': { bg: 'rgba(245,158,11,.1)', color: 'var(--warning)' },
};

export default function BackupsPage() {
  return (
    <DashboardLayout>
      <div className="flex justify-between items-start mb-5">
        <div>
          <h1 className="text-xl font-extrabold" style={{ color: 'var(--text-0)' }}>Backup & Restore</h1>
          <p className="text-xs mt-1" style={{ color: 'var(--text-2)' }}>{mockBackups.length} backups · Auto-backup every 24h</p>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid md:grid-cols-3 gap-3 mb-5">
        {[
          { icon: '📦', title: 'Full Backup', desc: 'Database + Configs + Certs', color: 'var(--accent-1)' },
          { icon: '🗄️', title: 'Database Only', desc: 'Users, Proxies, Traffic', color: 'var(--accent-2)' },
          { icon: '📤', title: 'Restore', desc: 'Upload & restore from file', color: 'var(--warning)' },
        ].map((b) => (
          <button key={b.title} className="glass-card p-5 text-left hover:scale-[1.01] transition-transform cursor-pointer group">
            <div className="flex items-start gap-3">
              <span className="text-2xl">{b.icon}</span>
              <div>
                <span className="font-bold text-sm" style={{ color: 'var(--text-0)' }}>{b.title}</span>
                <p className="text-[10px] mt-0.5" style={{ color: 'var(--text-3)' }}>{b.desc}</p>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Backup list */}
      <div className="glass-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <th className="text-left px-4 py-3 text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text-3)' }}>Backup</th>
              <th className="text-left px-4 py-3 text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text-3)' }}>Type</th>
              <th className="text-left px-4 py-3 text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text-3)' }}>Size</th>
              <th className="text-left px-4 py-3 text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text-3)' }}>By</th>
              <th className="text-left px-4 py-3 text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'var(--text-3)' }}>Date</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {mockBackups.map(bk => (
              <tr key={bk.id} className="table-row">
                <td className="px-4 py-3"><span className="text-xs font-mono" style={{ color: 'var(--text-1)' }}>{bk.name}</span></td>
                <td className="px-4 py-3">
                  <span className="badge" style={typeBadge[bk.type] || typeBadge.manual}>{bk.type}</span>
                </td>
                <td className="px-4 py-3 text-xs" style={{ color: 'var(--text-2)' }}>{bk.size}</td>
                <td className="px-4 py-3 text-xs" style={{ color: 'var(--text-2)' }}>{bk.admin}</td>
                <td className="px-4 py-3 text-xs" style={{ color: 'var(--text-2)' }}>{formatDate(bk.date)}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <button className="p-1 rounded hover:opacity-70 text-xs" title="Download">📥</button>
                    <button className="p-1 rounded hover:opacity-70 text-xs" title="Restore">🔄</button>
                    <button className="p-1 rounded hover:opacity-70 text-xs" title="Delete" style={{ color: 'var(--danger)' }}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}
